<div class="form-group">
    <label class="form-label"><?php echo e($label); ?> <?php echo $required ? "<span style='color: red'> *</span>" : ""; ?></label>
    <textarea
        name="<?php echo e($name); ?>"
        id="<?php echo e($name); ?>"
        <?php echo e($attributes->merge(['class' => 'form-control '.$class])); ?>><?php echo e(empty($value) ? empty(old($name)) ? '' : old($name) : $value); ?></textarea>
</div>
<?php /**PATH /home/buildwit/labora-source/resources/views/components/form/textarea.blade.php ENDPATH**/ ?>