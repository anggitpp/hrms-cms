<form id="form-edit" method="POST"
      action=" <?php echo e(route('payrolls.process.approve.update', $process->id)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
    <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nama','name' => 'name','placeholder' => 'Nama','value' => ''.e($user->name ?? Auth::user()->name).'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['readonly' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal','class' => 'col-md-12','name' => 'approved_date','value' => ''.e($process->approved_date ?? date('Y-m-d')).'']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Textarea::class, ['label' => 'Catatan','name' => 'approved_description','value' => ''.e($process->approved_description ?? '').'']); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3)): ?>
<?php $component = $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3; ?>
<?php unset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Radio::class, ['label' => 'Status','name' => 'approved_status','datas' => $status,'value' => ''.e($process->approved_status == 'p' ? 't' : $process->approved_status).'']); ?>
<?php $component->withName('form.radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc)): ?>
<?php $component = $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc; ?>
<?php unset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc); ?>
<?php endif; ?>
    <?php if($process->approved_status != 't'): ?>
        <input type="submit" class="btn btn-primary " style="width: 100%" value="Save"/>
    <?php endif; ?>
</form>
<?php /**PATH /home/buildwit/labora-source/resources/views/payrolls/process/approve-form.blade.php ENDPATH**/ ?>