<?php if($label): ?>
    <div class="form-group">
        <label><?php echo e($label); ?> <?php echo $required ? "<span style='color: red'> *</span>" : ""; ?></label>
        <select name="<?php echo e($name); ?>"
                class="select2 form-control form-control-lg"
                id="<?php echo e($name); ?>"
                <?php if($event): ?>
                onchange="<?php echo e($event); ?>"
            <?php endif; ?>
        >
            <?php if($options): ?>
                <option value=""><?php echo e($options); ?></option>
            <?php endif; ?>
            <?php if($all): ?>
                <option value="All">All</option>
            <?php endif; ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>" <?php echo e($key == $value || $key == old($name) ? 'selected' : ''); ?> ><?php echo e($values); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php if($required): ?>
            <div class="invalid-feedback" id="<?php echo e($name); ?>-error"></div>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="pr-1">
        <select name="<?php echo e($name); ?>"
                class="select2 form-control form-control-lg"
                id="<?php echo e($name); ?>"
                <?php if($event): ?>
                onchange="<?php echo e($event); ?>"
            <?php endif; ?>
        >
            <?php if($options): ?>
                <option value=""><?php echo e($options); ?></option>
            <?php endif; ?>
            <?php if($all): ?>
                <option value="All">All</option>
            <?php endif; ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>" <?php echo e($key == $value ? 'selected' : ''); ?> ><?php echo e($values); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
<?php endif; ?>
<?php /**PATH /home/buildwit/labora-source/resources/views/components/form/select.blade.php ENDPATH**/ ?>