<?php if($label): ?>
    <div class="form-group">
        <label><?php echo e($label); ?> <?php echo $required ? "<span style='color: red'> *</span>" : ""; ?></label>
        <select name="<?php echo e($name); ?>"
                class="select2 form-control form-control-lg"
                id="<?php echo e($name); ?>"
                <?php if($event): ?>
                onchange="<?php echo e($event); ?>"
            <?php endif; ?>
        >
            <?php if($options): ?>
                <option value=""><?php echo e($options); ?></option>
            <?php endif; ?>
            <?php if($all): ?>
                <option value="All">All</option>
            <?php endif; ?>
            <?php for($i = 1; $i<=12; $i++): ?>
                <option value="<?php echo e($i); ?>" <?php echo e($i == $value ? 'selected' : ''); ?> ><?php echo e(numToMonth($i)); ?></option>
            <?php endfor; ?>
        </select>
        <?php if($required): ?>
            <div class="invalid-feedback" id="<?php echo e($name); ?>-error"></div>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="pr-1">
        <select name="<?php echo e($name); ?>"
                class="select2 form-control form-control-lg"
                id="<?php echo e($name); ?>"
                <?php if($event): ?>
                onchange="<?php echo e($event); ?>"
            <?php endif; ?>
        >
            <?php if($options): ?>
                <option value=""><?php echo e($options); ?></option>
            <?php endif; ?>
            <?php if($all): ?>
                <option value="All">All</option>
            <?php endif; ?>
            <?php for($i = 1; $i<=12; $i++): ?>
                    <option value="<?php echo e($i); ?>" <?php echo e($i == $value ? 'selected' : ''); ?> ><?php echo e(numToMonth($i)); ?></option>
            <?php endfor; ?>
        </select>
    </div>
<?php endif; ?>
<script type="text/css">
    .select2-container{ width: 10% !important; }
</script>
<?php /**PATH /home/buildwit/labora-source/resources/views/components/form/select-month.blade.php ENDPATH**/ ?>