<?php $__env->startSection('content'); ?>
    <form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(empty($plan) ? route('recruitments.plans.store') : route('recruitments.plans.update', $plan->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php if(!empty($plan)): ?>
            <?php echo method_field('PATCH'); ?>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Data Kebutuhan</h4>
                <div>
                    <button type="reset" class="btn btn-primary mr-1 btn" onclick="document.getElementById('form').submit();">
                        Simpan
                    </button>
                    <a href="<?php echo e(route('recruitments.plans.index')); ?>" class="btn btn-outline-secondary mr-1">Kembali</a>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nomor Kebutuhan','required' => true,'name' => 'plan_number','value' => ''.e($plan->plan_number ?? $planNumber).'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['readonly' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Judul','required' => true,'name' => 'title','value' => ''.e($plan->title ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal Pengajuan','required' => true,'name' => 'propose_date','value' => ''.e($plan->propose_date ?? '').'']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Diajukan Oleh','required' => true,'name' => 'employee_id','options' => '- Pilih Pegawai -','datas' => $employees,'value' => ''.e($plan->employee_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Posisi','required' => true,'name' => 'position_id','options' => '- Pilih Posisi -','datas' => $positions,'value' => ''.e($plan->position_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal Kebutuhan','required' => true,'name' => 'need_date','value' => ''.e($plan->need_date ?? '').'']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-header" style="margin-top: -30px;">
                <h4 class="card-title">Data Rekrutmen</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Minimal Pendidikan','required' => true,'name' => 'education_id','options' => '- Pilih Pendidikan -','datas' => $education,'value' => ''.e($plan->education_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal367c11a296634e4aa4a4ccac390bf4940353fcc6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\DoubleInput::class, ['label' => 'Umur Dari','numeric' => true,'label2' => 'Umur Sampai','name' => 'age_from','name2' => 'age_to','value' => ''.e($plan->age_from ?? '').'','value2' => ''.e($plan->age_to ?? '').'']); ?>
<?php $component->withName('form.double-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal367c11a296634e4aa4a4ccac390bf4940353fcc6)): ?>
<?php $component = $__componentOriginal367c11a296634e4aa4a4ccac390bf4940353fcc6; ?>
<?php unset($__componentOriginal367c11a296634e4aa4a4ccac390bf4940353fcc6); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Minimum Experience','name' => 'experience','class' => 'col-md-6','value' => ''.e($plan->experience ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Lokasi','required' => true,'name' => 'location_id','options' => '- Pilih Lokasi -','datas' => $locations,'value' => ''.e($plan->location_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Radio::class, ['label' => 'Jenis Kelamin','datas' => $genders,'name' => 'gender','value' => ''.e($plan->gender ?? '').'']); ?>
<?php $component->withName('form.radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc)): ?>
<?php $component = $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc; ?>
<?php unset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Jumlah Orang','name' => 'number_of_people','numeric' => true,'class' => 'col-md-2','value' => ''.e($plan->number_of_people ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                    </div>
                </div>
                <?php if (isset($component)) { $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Textarea::class, ['label' => 'Catatan','name' => 'notes','value' => ''.e($plan->notes ?? '').'']); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3)): ?>
<?php $component = $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3; ?>
<?php unset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Textarea::class, ['label' => 'Alasan Perekrutan','name' => 'recruitment_reason','value' => ''.e($plan->recruitment_reason ?? '').'']); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3)): ?>
<?php $component = $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3; ?>
<?php unset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3); ?>
<?php endif; ?>
                <div class="row">
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\File::class, ['label' => 'File','name' => 'filename','value' => ''.e($plan->filename ?? '').'']); ?>
<?php $component->withName('form.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba)): ?>
<?php $component = $__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba; ?>
<?php unset($__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba); ?>
<?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Radio::class, ['label' => 'Status','name' => 'status','datas' => $listStatus,'value' => ''.e($plan->status ?? '').'']); ?>
<?php $component->withName('form.radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc)): ?>
<?php $component = $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc; ?>
<?php unset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/recruitments/plans/form.blade.php ENDPATH**/ ?>