<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('templates.employee_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header justify-content-between">
            <form class="form-inline" method="GET" id="form">
                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'filter','class' => 'mr-1','value' => ''.e($filter).'','placeholder' => 'Search ..']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal79be037cc48fef95092648bde7c356e360ff7912 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectYear::class, ['name' => 'filterYear','value' => ''.e($filterYear).'']); ?>
<?php $component->withName('form.select-year'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal79be037cc48fef95092648bde7c356e360ff7912)): ?>
<?php $component = $__componentOriginal79be037cc48fef95092648bde7c356e360ff7912; ?>
<?php unset($__componentOriginal79be037cc48fef95092648bde7c356e360ff7912); ?>
<?php endif; ?>
                <input type="submit" class="btn btn-primary" value="GO">
            </form>
            <?php if(isset($access['create'])): ?>
                <a href="<?php echo e(route('ess.leaves.create')); ?>" class="btn btn-primary"><i data-feather='plus'></i> Tambah Pengajuan</a>
            <?php endif; ?>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th width="5%" class="text-center">No</th>
                    <th width="10%">Nomor</th>
                    <th width="*">Tipe</th>
                    <th width="15%">Tgl Mulai</th>
                    <th width="15%">Tgl Selesai</th>
                    <th width="5%">Status</th>
                    <th width="13%" class="text-center">Kontrol</th>
                </tr>
                </thead>
                <tbody>
                <?php if(!$leaves->isEmpty()): ?>
                    <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($key+1); ?></td>
                            <td><?php echo e($r->number); ?></td>
                            <td><?php echo e($r->namaCuti); ?></td>
                            <td><?php echo e(setDate($r->start_date)); ?></td>
                            <td><?php echo e(setDate($r->end_date)); ?></td>
                            <td>
                                <?php if($r->approved_status == 't'): ?>
                                    <div class="badge badge-success">Disetujui</div>
                                <?php elseif($r->approved_status == 'f'): ?>
                                    <div class="badge badge-danger">Ditolak</div>
                                <?php else: ?>
                                    <div class="badge badge-secondary">Pending</div>
                                <?php endif; ?>
                            </td>
                            <td align="center">
                                <?php if(isset($access['edit']) && $r->approved_status != 't'): ?>
                                    <a href="<?php echo e(route('ess.leaves.edit', $r->id)); ?>" class="btn btn-icon btn-primary"><i data-feather="edit"></i></a>
                                <?php endif; ?>
                                <?php if(isset($access['destroy']) && $r->approved_status != 't'): ?>
                                    <button href="<?php echo e(route('ess.leaves.destroy', $r->id)); ?>" id="delete" class="btn btn-icon btn-danger">
                                        <i data-feather="trash-2"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" align="center">-- Empty Data --</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
            <?php echo e(generatePagination($leaves)); ?>

            <form action="" id="formDelete" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" style="display: none">
            </form>
        </div>
        <style>
            .select2{
                min-width: 100px;
            }
        </style>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/ess/leaves/index.blade.php ENDPATH**/ ?>