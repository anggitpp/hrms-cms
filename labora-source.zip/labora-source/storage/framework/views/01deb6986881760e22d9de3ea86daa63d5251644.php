<?php $__env->startSection('content'); ?>
    <?php
    $url = '/settings/menus/';
    ?>
<div class="card">
    <div class="card-header justify-content-between">
        <form class="form-inline" method="GET" id="form">
            <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'filter','class' => 'mr-1','value' => ''.e($filter).'','placeholder' => 'Search ..']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['name' => 'filterModul','value' => ''.e($filterModul).'','datas' => $moduls,'event' => 'document.getElementById(\'form\').submit();']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['name' => 'filterSubModul','value' => ''.e($filterSubModul).'','datas' => $submoduls,'event' => 'document.getElementById(\'form\').submit();']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
            <input type="submit" class="btn btn-primary" value="GO">
        </form>
        <button class="btn btn-primary btn-modal" data-toggle="modal" data-form="menu" data-action="create" data-url="<?php echo e($url); ?>">
            <i data-feather='plus'></i> Add Menu
        </button>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
            <tr>
                <th width="5%" class="text-center">No</th>
                <th width="*">Name</th>
                <th width="10%">Target</th>
                <th width="5%">Permissions</th>
                <th width="5%">Functions</th>
                <th width="5%">status</th>
                <th width="5%">urutan</th>
                <th class="text-center" width="15%">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php if(!$menus->isEmpty()): ?>
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($key+1); ?></td>
                        <td><?php echo e($r->name); ?></td>
                        <td><?php echo e($r->target); ?></td>
                        <td align="center">
                            <a href="<?php echo e(route('settings.menus.permission', $r->id)); ?>" class="btn btn-icon btn-info btn-modal">
                                <i data-feather='list'></i>
                            </a>
                        </td>
                        <td align="center">
                            <a href="<?php echo e(route('settings.menus.functions', $r->id)); ?>" class="btn btn-icon btn-info btn-modal">
                                <i data-feather='list'></i>
                            </a>
                        </td>
                        <td>
                            <div class="badge badge-<?php echo e($r->status == 't' ? 'success' : 'danger'); ?>"><?php echo e($r->status == 't' ? 'Aktif' : 'Tidak Aktif'); ?></div>
                        </td>
                        <td align="center"><?php echo e($r->order); ?></td>
                        <td align="center">
                            <a href="#" class="btn btn-icon btn-success btn-modal" data-form-id="modul" data-id="<?php echo e($r->id); ?>" data-url="<?php echo e($url); ?>" data-action="createChild">
                                <i data-feather="plus-square"></i>
                            </a>
                            <a href="#" class="btn btn-icon btn-primary btn-modal" data-form-id="modul" data-id="<?php echo e($r->id); ?>" data-url="<?php echo e($url); ?>" data-action="edit">
                                <i data-feather="edit"></i>
                            </a>
                            <?php if(!$r->menu->contains('parent_id', $r->id)): ?>
                            <button href="<?php echo e(route('settings.menus.destroy', $r->id)); ?>" id="delete" class="btn btn-icon btn-danger">
                                <i data-feather="trash-2"></i>
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $r->menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($k+2); ?></td>
                            <td><span style="margin-left: 30px;"><?php echo e($v->name); ?></span></td>
                            <td><?php echo e($v->target); ?></td>
                            <td align="center">
                                <a href="<?php echo e(route('settings.menus.permission', $v->id)); ?>" class="btn btn-icon btn-info btn-modal">
                                    <i data-feather='list'></i>
                                </a>
                            </td>
                            <td align="center">
                                <a href="<?php echo e(route('settings.menus.functions', $v->id)); ?>" class="btn btn-icon btn-info btn-modal">
                                    <i data-feather='list'></i>
                                </a>
                            </td>
                            <td>
                                <div class="badge badge-<?php echo e($v->status == 't' ? 'success' : 'danger'); ?>"><?php echo e($v->status == 't' ? 'Aktif' : 'Tidak Aktif'); ?></div>
                            </td>
                            <td align="center"><?php echo e($v->order); ?></td>
                            <td align="center">
                                <a href="#" class="btn btn-icon btn-primary btn-modal" data-form-id="modul" data-id="<?php echo e($v->id); ?>" data-url="<?php echo e($url); ?>" data-action="edit">
                                    <i data-feather="edit"></i>
                                </a>
                                <button href="<?php echo e(route('settings.menus.destroy', $v->id)); ?>" id="delete" class="btn btn-icon btn-danger">
                                    <i data-feather="trash-2"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="5" align="center">-- Empty Data --</td>
            </tr>
            <?php endif; ?>
            </tbody>
            <tfoot>

            </tfoot>
        </table>
        <?php echo e(generatePagination($menus)); ?>

        <form action="" id="formDelete" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input type="submit" style="display: none">
        </form>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideModalForm::class, ['title' => 'Form Menu']); ?>
<?php $component->withName('side-modal-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e)): ?>
<?php $component = $__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e; ?>
<?php unset($__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e); ?>
<?php endif; ?>
    <style>
        .select2{
            min-width: 150px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/settings/menus/index.blade.php ENDPATH**/ ?>