<?php if($label): ?>
    <div class="form-group">
    <label class="d-block mb-1"><?php echo e($label); ?> <?php echo $required ? "<span style='color: red'> *</span>" : ""; ?></label>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div <?php echo e($attributes->merge(['class' => 'custom-control custom-radio custom-control-inline '.$class])); ?>

        <?php if($event): ?>
            onclick="<?php echo e($event); ?>"
        <?php endif; ?>
        style="margin-bottom: 3px;">
            <?php
            $value = empty($value) ? $key : $value;
            ?>
            <input type="radio"
                   id="<?php echo e($name.'_'.$key); ?>"
                   name="<?php echo e($name); ?>"
                   value="<?php echo e($key); ?>"
                   class="custom-control-input col-md-4"
                <?php echo e($value == $key || $key == old($name) ? "checked=checked" : ""); ?>

            />
            <label class="custom-control-label" for="<?php echo e($name.'_'.$key); ?>"><?php echo e($values); ?></label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div <?php echo e($attributes->merge(['class' => 'custom-control custom-radio custom-control-inline '.$class])); ?>

             <?php if($event): ?>
             onclick="<?php echo e($event); ?>"
             <?php endif; ?>
             style="margin-bottom: 3px;">
            <?php
                $value = empty($value) ? $key : $value;
            ?>
            <input type="radio"
                   id="<?php echo e($name.'_'.$key); ?>"
                   name="<?php echo e($name); ?>"
                   value="<?php echo e($key); ?>"
                   class="custom-control-input col-md-4"
                    <?php echo e($value == $key || $key == old($name) ? "checked=checked" : ""); ?>

            />
            <label class="custom-control-label" for="<?php echo e($name.'_'.$key); ?>"><?php echo e($values); ?></label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php /**PATH /home/buildwit/labora-source/resources/views/components/form/radio.blade.php ENDPATH**/ ?>