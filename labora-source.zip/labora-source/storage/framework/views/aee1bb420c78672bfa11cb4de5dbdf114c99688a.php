<?php
    $url = "/payrolls/process/";
?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header justify-content-between">
            <form class="form-inline" method="GET" id="form">
                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['name' => 'filterType','datas' => $types,'value' => ''.e($filterType).'','event' => 'document.getElementById(\'form\').submit();']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal79be037cc48fef95092648bde7c356e360ff7912 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectYear::class, ['name' => 'filterYear','value' => ''.e($filterYear).'']); ?>
<?php $component->withName('form.select-year'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-1','placeholder' => 'Search ..']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal79be037cc48fef95092648bde7c356e360ff7912)): ?>
<?php $component = $__componentOriginal79be037cc48fef95092648bde7c356e360ff7912; ?>
<?php unset($__componentOriginal79be037cc48fef95092648bde7c356e360ff7912); ?>
<?php endif; ?>
                <input type="submit" class="btn btn-primary" value="GO">
            </form>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th width="5%" class="text-center">No</th>
                    <th width="10%">Bulan</th>
                    <th width="15%" class="text-center">Total Pegawai</th>
                    <th width="*" class="text-center">Total Nilai</th>
                    <th width="12%">Status Approve</th>
                    <th width="12%">Diapprove Oleh</th>
                    <th width="5%">Proses</th>
                </tr>
                </thead>
                <tbody>
                    <?php for($i = 1; $i<=12; $i++): ?>
                        <?php
                            $r = DB::table('payroll_processes')->where('month', $i)->where('year', $filterYear)->where('type_id', $filterType)->first();
                            $totalValues = !empty($r->total_values) ? setCurrency($r->total_values) : '';
                            $approvedBy = !empty($r->approved_by) ? DB::table('app_users')->find($r->approved_by)->name : '';
                        ?>
                        <tr>
                            <td class="text-center"><?php echo e($i); ?></td>
                            <td><?php echo e(numToMonth($i)); ?></td>
                            <td class="text-center"><?php echo e($r->total_employees ?? ''); ?></td>
                            <td class="text-center"><?php echo e($totalValues); ?></td>
                            <td>
                                <?php if(!empty($r->approved_status)): ?>
                                    <a href="#" class="btn-modal" data-url="<?php echo e($url); ?>" data-action="approve/edit" data-id="<?php echo e($r->id); ?>">
                                        <?php if($r->approved_status == 't'): ?>
                                            <div class="badge badge-success">Disetujui</div>
                                        <?php elseif($r->approved_status == 'f'): ?>
                                            <div class="badge badge-danger">Ditolak</div>
                                        <?php else: ?>
                                            <div class="badge badge-secondary">Pending</div>
                                        <?php endif; ?>
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($approvedBy); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('payrolls.process.show', [$filterType, $i, $filterYear])); ?>" class="btn btn-icon btn-info">
                                    <i data-feather="list"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideModalForm::class, ['title' => 'Approve '.e($arrMenu['name']).' ']); ?>
<?php $component->withName('side-modal-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e)): ?>
<?php $component = $__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e; ?>
<?php unset($__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e); ?>
<?php endif; ?>
    <style>
        .select2{
            min-width: 200px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/payrolls/process/index.blade.php ENDPATH**/ ?>