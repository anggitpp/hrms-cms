<?php if($label): ?>
    <div class="form-group">
        <label for="first-name-vertical"><?php echo e($label); ?> <?php echo $required ? "<span style='color: red'> *</span>" : ""; ?> </label>
        <input type="<?php echo e($password ? 'password' : 'text'); ?>"
               id="<?php echo e($name); ?>"
               <?php echo e($attributes->merge(['class' => 'form-control '.$class])); ?>

               name="<?php echo e($name); ?>"
               value="<?php echo e(empty(old($name)) ? ($currency ? setCurrency($value) : $value) : old($name)); ?>"
               placeholder="<?php echo e($placeholder); ?>"
            <?php echo e($nospacing ? 'onkeyup=setNoSpacing(this);' : ''); ?>

            <?php echo e($numeric ? 'onkeyup=setNumber(this);' : ''); ?>

            <?php echo e($currency ? 'onkeyup=setCurrency(this);' : ''); ?>

            <?php echo e($currency ? 'style=text-align:right;' : ''); ?>

        />
        <?php if($required): ?>
            <div class="invalid-feedback" id="<?php echo e($name); ?>-error"></div>
        <?php endif; ?>
    </div>
<?php else: ?>
    <input type="text"
           id="<?php echo e($name); ?>"
           <?php echo e($attributes->merge(['class' => 'form-control '.$class])); ?>

           name="<?php echo e($name); ?>"
           value="<?php echo e(empty($value) ? '' : $value); ?>"
           placeholder="<?php echo e($placeholder); ?>"
    />
<?php endif; ?>
<?php /**PATH /home/buildwit/labora-source/resources/views/components/form/input.blade.php ENDPATH**/ ?>