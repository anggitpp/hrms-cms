<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header justify-content-between">
            <form class="form-inline" method="GET" id="form">
                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'filter','class' => 'mr-1','value' => ''.e($filter).'','placeholder' => 'Search ..']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                <input type="submit" class="btn btn-primary" value="GO">
            </form>
            <button class="btn btn-primary btn-modal" data-toggle="modal" data-form="group" data-action="create" data-url="/settings/groups/">
                <i data-feather='plus'></i> Add Group
            </button>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th width="5%" class="text-center">No</th>
                    <th width="*">Name</th>
                    <th width="30%">Description</th>
                    <th width="5%">Status</th>
                    <th style="text-align: center" width="13%">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php if(!$groups->isEmpty()): ?>
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($key+1); ?></td>
                            <td><?php echo e($r->name); ?></td>
                            <td><?php echo e($r->description); ?></td>
                            <td>
                                <div class="badge badge-<?php echo e($r->status == 't' ? 'success' : 'danger'); ?>"><?php echo e($r->status == 't' ? 'Aktif' : 'Tidak Aktif'); ?></div>
                            </td>
                            <td align="center">
                                <a href="#" class="btn btn-icon btn-primary btn-modal" data-form-id="modul" data-id="<?php echo e($r->id); ?>" data-url="/settings/groups/" data-action="edit">
                                    <i data-feather="edit"></i>
                                </a>
                                <button href="<?php echo e(route('settings.groups.destroy', $r->id)); ?>" id="delete" class="btn btn-icon btn-danger">
                                    <i data-feather="trash-2"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" align="center">-- Empty Data --</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
            <?php echo e(generatePagination($groups)); ?>

            <form action="" id="formDelete" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" style="display: none">
            </form>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideModalForm::class, ['title' => 'Form Group']); ?>
<?php $component->withName('side-modal-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e)): ?>
<?php $component = $__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e; ?>
<?php unset($__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/settings/groups/index.blade.php ENDPATH**/ ?>