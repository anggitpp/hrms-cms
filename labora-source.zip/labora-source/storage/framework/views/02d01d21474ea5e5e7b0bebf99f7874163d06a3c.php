<div class="modal modal-slide-in event-sidebar fade" id="form-modal">
    <div class="modal-dialog sidebar-lg">
        <div class="modal-content p-0">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
            <div class="modal-header mb-1">
                <h5 class="modal-title"><?php echo e($title); ?></h5>
            </div>
            <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
            </div>
        </div>
    </div>
</div>

<?php /**PATH /home/buildwit/labora-source/resources/views/components/side-modal-form.blade.php ENDPATH**/ ?>