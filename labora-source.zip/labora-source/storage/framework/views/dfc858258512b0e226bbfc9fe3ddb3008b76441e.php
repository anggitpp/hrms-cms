<div class="form-group">
    <label for="customFile1"><?php echo e($label); ?> <?php echo $required ? "<span style='color: red'> *</span>" : ""; ?></label>
    <div class="custom-file">
        <div id="fileExist_<?php echo e($name); ?>" class="d-flex" style="<?php echo e($value ? '' : 'display: none !important'); ?>">
            <a href="<?php echo e(asset('storage'.$value)); ?>" download><?php echo $value ? getIcon($value, 'fa-3x') : ''; ?></a>
            &nbsp;&nbsp;
            <div class="btn btn-primary mr-75 mb-0 waves-effect waves-float waves-light btnRemove" id="btnFile_<?php echo e($name); ?>">Remove</div>
        </div>
        <div id="fileEmpty_<?php echo e($name); ?>" style="<?php echo e($value ? 'display: none' : ''); ?>">
            <input type="file" <?php echo $imageOnly ? "accept='image/*'" : ""; ?> class="custom-file-input" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>">
            <label class="custom-file-label" for="<?php echo e($name); ?>">Choose your file</label>
        </div>
    </div>
    <input type="hidden" id="exist_<?php echo e($name); ?>" name="exist_<?php echo e($name); ?>" value="<?php echo e($value); ?>"/>
</div>
<?php /**PATH /home/buildwit/labora-source/resources/views/components/form/file.blade.php ENDPATH**/ ?>