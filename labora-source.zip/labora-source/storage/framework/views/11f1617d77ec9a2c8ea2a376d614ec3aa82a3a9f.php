<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header justify-content-between">
            <form class="form-inline" method="GET" id="form">
                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'filter','class' => 'mr-1','value' => ''.e($filter).'','placeholder' => 'Cari ..']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                <?php if(!Session::get('sessionBuilding')): ?>
                    <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['name' => 'filterRegion','options' => '- Pilih Wilayah -','datas' => $regions,'value' => ''.e($filterRegion ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                <?php endif; ?>
                <input type="submit" class="btn btn-primary" value="GO">
            </form>
            <?php if(isset($access['create'])): ?>
                <a href="<?php echo e(route('bms.buildings.create')); ?>" class="btn btn-primary"><i data-feather='plus'></i> Tambah Gedung</a>
            <?php endif; ?>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th width="5%">No</th>
                    <th width="*">Nama</th>
                    <th width="5%">Code</th>
                    <th width="15%">Wilayah</th>
                    <th width="10%">Tipe</th>
                    <th width="5%">Status</th>
                    <th width="13%">Kontrol</th>
                </tr>
                </thead>
                <tbody>
                <?php if(!$buildings->isEmpty()): ?>
                    <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($r->name); ?></td>
                            <td><?php echo e($r->code); ?></td>
                            <td><?php echo e($masters['ELK'][$r->region_id]); ?></td>
                            <td><?php echo e($masters['BTP'][$r->type_id]); ?></td>
                            <td align="center">
                                <?php if($r->status == 't'): ?>
                                    <div class="badge badge-success">Aktif</div>
                                <?php else: ?>
                                    <div class="badge badge-danger">Tidak Aktif</div>
                                <?php endif; ?>
                            </td>
                            <td align="center">
                                <?php if(isset($access['edit'])): ?>
                                    <a href="<?php echo e(route('bms.buildings.edit', $r->id)); ?>" class="btn btn-icon btn-primary"><i data-feather="edit"></i></a>
                                <?php endif; ?>
                                <?php if(isset($access['destroy'])): ?>
                                    <button href="<?php echo e(route('bms.buildings.destroy', $r->id)); ?>" id="delete" class="btn btn-icon btn-danger">
                                        <i data-feather="trash-2"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" align="center">-- Empty Data --</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
            <?php echo e(generatePagination($buildings)); ?>

            <form action="" id="formDelete" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" style="display: none">
            </form>
        </div>
    </div>
    <style>
        .select2{
            min-width: 150px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/bms/buildings/index.blade.php ENDPATH**/ ?>