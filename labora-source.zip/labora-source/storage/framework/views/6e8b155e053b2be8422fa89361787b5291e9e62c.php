<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4>Lokasi Kerja</h4>
            <div class="justify-content-between form-inline">
                <a href="<?php echo e(route('monitorings.qr.generateQR')); ?>" class="btn btn-primary mr-1">Generate QR</a>
            </div>
        </div>
        <div class="card-body form-inline justify-content-start">
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="width: 10%" class="mr-2">
                    <div>
                        <h5 class="text-center"><?php echo e($r->name); ?></h5>
                        <div class="text-center">
                            <a href="<?php echo asset('storage/uploads/monitoring/qr/'.$r->id.'.png'); ?>" download> <img width="100" height="100" src="<?php echo asset('storage/uploads/monitoring/qr/'.$r->id.'.png'); ?> "></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/monitorings/qr/index.blade.php ENDPATH**/ ?>