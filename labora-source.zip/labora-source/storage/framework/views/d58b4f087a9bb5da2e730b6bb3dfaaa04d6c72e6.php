<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Data Pegawai</h4>
            <div>
                <button type="reset" class="btn btn-primary mr-1 btn" onclick="document.getElementById('form').submit();">
                    Simpan
                </button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-secondary mr-1">Kembali</a>
            </div>
        </div>
        <div class="card-body">
            <form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(empty($emp) ? route('employees.'.$arrMenu['target'].'.store') : route('employees.'.$arrMenu['target'].'.update', $emp->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php if(!empty($emp)): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>
                <ul class="nav nav-tabs" role="tablist" style="border-bottom: 1px solid; color: #DFDFDF;">
                    <li class="nav-item">
                        <a class="nav-link active" id="profile-tab" data-toggle="tab" href="#profile" aria-controls="profile" role="tab" aria-selected="true">Identitas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="contract-tab" data-toggle="tab" href="#contract" aria-controls="contract" role="tab" aria-selected="true">Posisi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="payroll-tab" data-toggle="tab" href="#payroll" aria-controls="payroll" role="tab" aria-selected="true">Payroll</a>
                    </li>
                </ul>
                <!-- PROFILE -->
                <div class="tab-content">
                    <div class="tab-pane active" id="profile" aria-labelledby="profile-tab" role="tabpanel">
                        <div class="row">
                            <div class="col-md-4">
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nama','name' => 'name','required' => true,'placeholder' => 'Nama','value' => ''.e($emp->name ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Tempat Lahir','required' => true,'name' => 'birth_place','placeholder' => 'Tempat Lahir','value' => ''.e($emp->birth_place ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Agama','name' => 'religion_id','required' => true,'datas' => $masters['SAG'],'options' => '- Pilih Agama -','value' => ''.e($emp->religion_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                            </div>
                            <div class="col-md-4">
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Alias','name' => 'nickname','placeholder' => 'Alias','value' => ''.e($emp->nickname ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal Lahir','required' => true,'name' => 'birth_date','value' => ''.e($emp->birth_date ?? '').'','class' => 'col-md-6']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Radio::class, ['label' => 'Jenis Kelamin','name' => 'gender','datas' => $gender,'value' => ''.e($emp->gender ?? '').'']); ?>
<?php $component->withName('form.radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc)): ?>
<?php $component = $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc; ?>
<?php unset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc); ?>
<?php endif; ?>
                            </div>
                            <div class="col-md-4">
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'NIK','name' => 'emp_number','placeholder' => 'NIK','value' => ''.e($emp->emp_number ?? $empNumber).'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['readonly' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nomor KTP','required' => true,'numeric' => true,'name' => 'identity_number','placeholder' => 'Nomor KTP','value' => ''.e($emp->identity_number ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['maxlength' => '16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Email','name' => 'email','placeholder' => 'Email','value' => ''.e($emp->email ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <?php if (isset($component)) { $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Textarea::class, ['label' => 'Alamat Domisili','name' => 'address','value' => ''.e($emp->address ?? '').'']); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3)): ?>
<?php $component = $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3; ?>
<?php unset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3); ?>
<?php endif; ?>
                            </div>
                            <div class="col-md-4">
                                <?php if (isset($component)) { $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Textarea::class, ['label' => 'Alamat KTP','name' => 'identity_address','value' => ''.e($emp->identity_address ?? '').'']); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3)): ?>
<?php $component = $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3; ?>
<?php unset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3); ?>
<?php endif; ?>
                            </div>
                            <div class="col-md-4">
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Status Perkawinan','name' => 'marital_id','datas' => $masters['ESK'],'options' => '- Pilih Status Perkawinan -','value' => ''.e($emp->marital_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nomor Telp','name' => 'phone','placeholder' => 'Nomor Telp','value' => ''.e($emp->phone ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Status Pegawai','required' => true,'name' => 'status_id','datas' => $masters['ESP'],'options' => '- Pilih Status Pegawai -','value' => ''.e($emp->status_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\File::class, ['label' => 'Foto','imageOnly' => true,'name' => 'photo','value' => ''.e($emp->photo ?? '').'']); ?>
<?php $component->withName('form.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba)): ?>
<?php $component = $__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba; ?>
<?php unset($__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba); ?>
<?php endif; ?>
                            </div>
                            <div class="col-md-4">
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nomor Handphone','name' => 'mobile_phone','placeholder' => 'Nomor Handphone','value' => ''.e($emp->mobile_phone ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal Masuk','required' => true,'name' => 'join_date','value' => ''.e($emp->join_date ?? '').'','class' => 'col-md-6']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\File::class, ['label' => 'File KTP','imageOnly' => true,'name' => 'identity_file','value' => ''.e($emp->identity_file ?? '').'']); ?>
<?php $component->withName('form.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba)): ?>
<?php $component = $__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba; ?>
<?php unset($__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba); ?>
<?php endif; ?>
                            </div>
                            <div class="col-md-4">
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Golongan Darah','name' => 'blood_type','datas' => $bloodTypes,'options' => '- Pilih Golongan Darah -','value' => ''.e($emp->blood_type ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal Keluar','name' => 'leave_date','value' => ''.e($emp->leave_date ?? '').'','class' => 'col-md-6']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- CONTRACT -->
                    <div class="tab-pane" id="contract" aria-labelledby="contract-tab" role="tabpanel">
                        <div class="row">
                            <div class="col-md-6">
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Posisi','required' => true,'name' => 'position_id','datas' => $masters['EJP'],'options' => '- Pilih Posisi -','value' => ''.e($empc->position_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Pangkat','required' => true,'name' => 'rank_id','event' => 'getSub(this.value, \'grade_id\');','datas' => $masters['EP'],'options' => '- Pilih Pangkat -','value' => ''.e($empc->rank_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal Mulai','required' => true,'name' => 'start_date','value' => ''.e($empc->start_date ?? '').'','class' => 'col-md-4']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nomor SK','name' => 'sk_number','placeholder' => 'Nomor SK','value' => ''.e($empc->sk_number ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Atasan','name' => 'leader_id','value' => ''.e($placementData->leaderName ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['readonly' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Lokasi Kerja','required' => true,'name' => 'location_id','event' => 'getSub(this.value, \'area_id\');','datas' => $masters['ELK'],'options' => '- Pilih Lokasi Kerja -','value' => ''.e($empc->location_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Shift Kerja','name' => 'shift_id','datas' => $shifts,'options' => '- Pilih Shift Kerja -','value' => ''.e($empc->shift_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Keterangan','name' => 'description','placeholder' => 'Keterangan','value' => ''.e($empc->description ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Tipe Pegawai','required' => true,'name' => 'type_id','datas' => $masters['ETP'],'options' => '- Pilih Tipe Pegawai -','value' => ''.e($empc->type_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Grade','name' => 'grade_id','datas' => $masters['EG'],'options' => '- Pilih Grade -','value' => ''.e($empc->grade_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal Selesai','name' => 'end_date','value' => ''.e($empc->end_date ?? '').'','class' => 'col-md-4']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Divisi','required' => true,'name' => 'placement_id','datas' => $placements,'options' => '- Pilih Divisi -','value' => ''.e($empc->placement_id ?? '').'','event' => 'getPlacementDetail(this.value);']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Admin','name' => 'administration_id','value' => ''.e($placementData->adminName ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['readonly' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Area Kerja','name' => 'area_id','datas' => $masters['EAK'],'options' => '- Pilih Area Kerja -','value' => ''.e($empc->area_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\File::class, ['label' => 'File Pendukung','name' => 'filename','value' => ''.e($empc->filename ?? '').'']); ?>
<?php $component->withName('form.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba)): ?>
<?php $component = $__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba; ?>
<?php unset($__componentOriginal93b28f1de9746c8f590ee165d439cdf51f94d2ba); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- PAYROLL -->
                    <div class="tab-pane" id="payroll" aria-labelledby="payroll-tab" role="tabpanel">
                        <div class="row">
                            <div class="col-md-6">
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Jenis Payroll','required' => true,'name' => 'payroll_id','datas' => $payrolls,'options' => '- Pilih Jenis Payroll -','value' => ''.e($empp->payroll_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['label' => 'Bank','required' => true,'name' => 'bank_id','datas' => $masters['SB'],'options' => '- Pilih Bank -','value' => ''.e($empp->bank_id ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nama Pemilik Rekening','name' => 'account_name','placeholder' => 'Nama Pemilik Rekening','value' => ''.e($empp->account_name ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nomor Rekening','name' => 'account_number','placeholder' => 'Nomor Rekening','value' => ''.e($empp->account_number ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'No. BPJS TK','name' => 'bpjs_tk_number','placeholder' => 'No. BPJS TK','value' => ''.e($empp->bpjs_tk_number ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal BPJS TK','name' => 'bpjs_tk_date','value' => ''.e($empp->bpjs_tk_date ?? '').'','class' => 'col-md-4']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'No. NPWP','name' => 'npwp_number','placeholder' => 'No. NPWP','value' => ''.e($empp->npwp_number ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal NPWP','name' => 'npwp_date','value' => ''.e($empp->npwp_date ?? '').'','class' => 'col-md-4']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'No. BPJS KS','name' => 'bpjs_number','placeholder' => 'No. BPJS KS','value' => ''.e($empp->bpjs_number ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Datepicker::class, ['label' => 'Tanggal BPJS KS','name' => 'bpjs_date','value' => ''.e($empp->bpjs_date ?? '').'','class' => 'col-md-4']); ?>
<?php $component->withName('form.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200)): ?>
<?php $component = $__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200; ?>
<?php unset($__componentOriginal5ea59abbe90178d045d7e332a8c22321309a2200); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function getPlacementDetail(value) {
            $.ajax({
                url: '/employees/actives/getPlacementDetail/' + value,
                method: "get",
                dataType: "json",
                success: function (data) {
                    $('#leader_id').val(data['leaderName']);
                    $('#administration_id').val(data['adminName']);
                },
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/employees/employees/form.blade.php ENDPATH**/ ?>