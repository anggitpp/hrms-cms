<?php
$class = empty($class) ? 'col-md-3' : $class;
?>

<?php if($label): ?>
    <div class="form-group">
        <label for="fp-default"><?php echo e($label); ?> <?php echo $required ? "<span style='color: red'> *</span>" : ""; ?></label>
        <div class="input-group input-group-merge" >
            <div class="input-group-prepend">
                <span class="input-group-text"><i data-feather='calendar'></i></span>
            </div>
            <input type="text"
                   id="<?php echo e($name); ?>"
                   name="<?php echo e($name); ?>"
                   <?php echo e($attributes->merge(['class' => 'form-control flatpickr-basic '.$class])); ?>

                   value="<?php echo e(empty($value) ? empty(old($name)) ? '' : old($name) : setDate($value)); ?>"
            />
        </div>
        <?php if($required): ?>
            <div class="invalid-feedback" id="<?php echo e($name); ?>-error"></div>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="input-group input-group-merge">
        <div class="input-group-prepend">
            <span class="input-group-text"><i data-feather='calendar'></i></span>
        </div>
        <input type="text"
               id="<?php echo e($name); ?>"
               name="<?php echo e($name); ?>"
               <?php echo e($attributes->merge(['class' => 'form-control flatpickr-basic '.$class])); ?>

               value="<?php echo e(empty($value) ? empty(old($name)) ? '' : old($name) : setDate($value)); ?>"
        />
    </div>
<?php endif; ?>
<?php /**PATH /home/buildwit/labora-source/resources/views/components/form/datepicker.blade.php ENDPATH**/ ?>