<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Tambah Data</h4>
            <div>
                <button type="reset" class="btn btn-primary mr-1 btn" onclick="document.getElementById('form').submit();">
                    Simpan
                </button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-secondary mr-1">Kembali</a>
            </div>
        </div>
        <div class="card-body">
            <form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(empty($component) ? route('payrolls.'.$arrMenu['target'].'.store', $id) : route('payrolls.'.$arrMenu['target'].'.update', $component->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php if(!empty($component)): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>
                <div class="card-title">
                    <h5>Data Komponen</h5>
                    <hr>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Master Gaji','name' => '','value' => ''.e($type->name).'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['readonly' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nama','required' => true,'name' => 'name','value' => ''.e($component->name ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Textarea::class, ['label' => 'Keterangan','name' => 'description','value' => ''.e($component->description ?? '').'']); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3)): ?>
<?php $component = $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3; ?>
<?php unset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3); ?>
<?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Komponen','name' => '','value' => ''.e($componentType).'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['readonly' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Kode','required' => true,'name' => 'code','class' => 'col-md-2','value' => ''.e($component->code ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Urutan','name' => 'order','class' => 'col-md-2','value' => ''.e($component->order ?? $lastOrder).'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['readonly' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Radio::class, ['label' => 'Method','name' => 'component_method','datas' => $methods,'value' => ''.e($component->method ?? '').'','event' => 'setParameter()']); ?>
<?php $component->withName('form.radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc)): ?>
<?php $component = $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc; ?>
<?php unset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc); ?>
<?php endif; ?>
                        <div id="divInput" style="<?php echo e(isset($component->method) ? $component->method == 1 ? 'display:none' : 'display:block' : 'display:none'); ?>">
                            <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Nilai','name' => 'method_value','class' => 'col-md-4','value' => ''.e($component->method_value ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Radio::class, ['label' => 'Status','name' => 'status','datas' => $status,'value' => ''.e($component->status ?? '').'']); ?>
<?php $component->withName('form.radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc)): ?>
<?php $component = $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc; ?>
<?php unset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc); ?>
<?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function setParameter(){
            val = document.querySelector('input[name="component_method"]:checked').value;
            inputValue = document.getElementById('divInput');
            if(val == 1){
                inputValue.style.display = 'none';
            }else{
                inputValue.style.display = 'block';
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/payrolls/components/form.blade.php ENDPATH**/ ?>