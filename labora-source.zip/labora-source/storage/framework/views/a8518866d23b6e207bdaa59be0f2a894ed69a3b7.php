<?php $__env->startSection('content'); ?>
    <?php
    $url = '/recruitments/plans/';
    ?>
    <div class="card">
        <div class="card-header justify-content-between">
            <form class="form-inline" method="GET" id="form">
                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'filter','class' => 'mr-1','value' => ''.e($filter).'','placeholder' => 'Search ..']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                <input type="submit" class="btn btn-primary" value="GO">
            </form>
            <?php if(isset($access['create'])): ?>
                <a href="<?php echo e(route('recruitments.plans.create')); ?>" class="btn btn-primary"><i data-feather='plus'></i> Tambah Kebutuhan</a>
            <?php endif; ?>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th width="5%" class="text-center">No</th>
                    <th width="10%">Nomor</th>
                    <th width="20%">Judul</th>
                    <th width="15%">Tgl Pengajuan</th>
                    <th width="15%">Posisi</th>
                    <th width="10%">Jumlah</th>
                    <th width="5%">Status</th>
                    <th style="text-align: center" width="13%">Kontrol</th>
                </tr>
                </thead>
                <tbody>
                <?php if(!$plans->isEmpty()): ?>
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $totalAppl = DB::table('recruitment_applicants')->where('plan_id', $r->id)->count();
                        $totalPeople = ($totalAppl ?? 0) . ' / '. ($r->number_of_people ?? 0);
                        $badge = $totalAppl >= $r->number_of_people ? 'success' : ($totalAppl != 0 ? 'info' : 'secondary');
                        ?>
                        <tr>
                            <td class="text-center"><?php echo e($key+1); ?></td>
                            <td align="left"><?php echo e($r->plan_number); ?></td>
                            <td><?php echo e($r->title); ?></td>
                            <td><?php echo e(setDate($r->propose_date)); ?></td>
                            <td><?php echo e($r->name); ?></td>
                            <td><a href="#" class="badge badge-<?php echo $badge; ?> btn-modal-form" data-id="<?php echo e($r->id); ?>" data-url="<?php echo e($url); ?>" data-action="show"><?php echo e($totalPeople); ?></a></td>
                            <td><?php echo getStatusApproval($r->status); ?></td>
                            <td align="center">
                                 <?php if(isset($access['edit'])): ?>
                                    <a href="<?php echo e(route('recruitments.plans.edit', $r->id)); ?>" class="btn btn-icon btn-primary"><i data-feather="edit"></i></a>
                                <?php endif; ?>
                                <?php if(isset($access['destroy'])): ?>
                                    <button href="<?php echo e(route('recruitments.plans.destroy', $r->id)); ?>" id="delete" class="btn btn-icon btn-danger">
                                        <i data-feather="trash-2"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" align="center">-- Empty Data --</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
            <?php echo e(generatePagination($plans)); ?>

            <form action="" id="formDelete" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" style="display: none">
            </form>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ModalForm::class, ['title' => 'List Applicant','size' => 'modal-lg']); ?>
<?php $component->withName('modal-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce)): ?>
<?php $component = $__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce; ?>
<?php unset($__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/recruitments/plans/index.blade.php ENDPATH**/ ?>