<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header justify-content-between">
            <form class="form-inline" method="GET" id="form">
                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'filter','class' => 'mr-1','value' => ''.e($filter).'','placeholder' => 'Cari ..']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['name' => 'filterLocation','options' => '- Pilih Lokasi Kerja -','datas' => $locations,'value' => ''.e($filterLocation ?? '').'']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal3c2e9a0b63ed1831aa934d6cc8356b767b33cf80 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectMonth::class, ['name' => 'filterMonth','event' => 'document.getElementById(\'form\').submit();','value' => ''.e($filterMonth ?? date('m')).'']); ?>
<?php $component->withName('form.select-month'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c2e9a0b63ed1831aa934d6cc8356b767b33cf80)): ?>
<?php $component = $__componentOriginal3c2e9a0b63ed1831aa934d6cc8356b767b33cf80; ?>
<?php unset($__componentOriginal3c2e9a0b63ed1831aa934d6cc8356b767b33cf80); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal79be037cc48fef95092648bde7c356e360ff7912 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectYear::class, ['name' => 'filterYear','event' => 'document.getElementById(\'form\').submit();','value' => ''.e($filterYear ?? date('Y')).'']); ?>
<?php $component->withName('form.select-year'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal79be037cc48fef95092648bde7c356e360ff7912)): ?>
<?php $component = $__componentOriginal79be037cc48fef95092648bde7c356e360ff7912; ?>
<?php unset($__componentOriginal79be037cc48fef95092648bde7c356e360ff7912); ?>
<?php endif; ?>
                <input type="submit" class="btn btn-primary" value="GO">
            </form>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th width="5%">No</th>
                    <th class="text-center" width="3%">Foto</th>
                    <th width="15%">Nama Pegawai</th>
                    <th width="5%">NIK</th>
                    <th width="5%">Tanggal</th>
                    <th width="*">Keterangan</th>
                    <th width="15%">Lokasi</th>
                    <th width="5%">Jam</th>
                    <th width="13%" class="text-center">Kontrol</th>
                </tr>
                </thead>
                <tbody>
                <?php if(!$reports->isEmpty()): ?>
                    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td class="text-center">
                                <?php if($r->image): ?>
                                    <a href="<?php echo e(asset('storage'.$r->image)); ?>" download>
                                        <img src="<?php echo e(asset('storage'.$r->image)); ?>" height="30" width="30">
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($r->name); ?></td>
                            <td class="text-center"><?php echo e($r->emp_number); ?></td>
                            <td><?php echo e(setDate($r->date)); ?></td>
                            <td><?php echo e($r->description); ?></td>
                            <td><?php echo e($r->location); ?></td>
                            <td><?php echo e($r->time); ?></td>
                            <td align="center">
                                <?php if(isset($access['edit'])): ?>
                                    <a href="<?php echo e(route('monitorings.reports.edit', $r->id)); ?>" class="btn btn-icon btn-primary"><i data-feather="edit"></i></a>
                                <?php endif; ?>
                                <?php if(isset($access['destroy'])): ?>
                                    <button href="<?php echo e(route('monitorings.reports.destroy', $r->id)); ?>" id="delete" class="btn btn-icon btn-danger">
                                        <i data-feather="trash-2"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" align="center">-- Empty Data --</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
            <?php echo e(generatePagination($reports)); ?>

            <form action="" id="formDelete" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" style="display: none">
            </form>
        </div>
    </div>
    <style>
        .select2{
            min-width: 150px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/monitorings/reports/index.blade.php ENDPATH**/ ?>