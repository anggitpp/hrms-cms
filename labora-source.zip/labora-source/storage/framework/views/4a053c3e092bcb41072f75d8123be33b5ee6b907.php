<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header justify-content-between">
            <form class="form-inline" method="GET" id="form">
                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'filter','class' => 'mr-1','value' => ''.e($filter).'','placeholder' => 'Search ..']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                <input type="submit" class="btn btn-primary" value="GO">
                <div style="position:absolute; right: 5px;">
                    <?php if (isset($component)) { $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Radio::class, ['name' => 'filterStatus','class' => 'mr-1','value' => ''.e($filterStatus).'','datas' => $status,'event' => 'document.getElementById(\'form\').submit();']); ?>
<?php $component->withName('form.radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc)): ?>
<?php $component = $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc; ?>
<?php unset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc); ?>
<?php endif; ?>
                </div>
            </form>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th width="5%" class="text-center">No</th>
                    <th width="10%">Username</th>
                    <th width="*">Nama User</th>
                    <th width="15%">Perangkat</th>
                    <th width="12%">Tanggal</th>
                    <th width="10%">Jam</th>
                    <th width="5%">Status</th>
                    <th width="13%" style="text-align: center">Kontrol</th>
                </tr>
                </thead>
                <tbody>
                <?php if(!$activations->isEmpty()): ?>
                    <?php $__currentLoopData = $activations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          list($date, $time) = explode(' ', $r->created_at);
                        ?>
                        <tr>
                            <td class="text-center"><?php echo e($key+1); ?></td>
                            <td><?php echo e($r->username); ?></td>
                            <td><?php echo e($r->name); ?></td>
                            <td><?php echo e($r->device_name); ?></td>
                            <td><?php echo e($date); ?></td>
                            <td><?php echo e(substr($time, 0, 5)); ?></td>
                            <td>
                                <div class="badge badge-<?php echo e($r->status == 't' ? 'success' : 'danger'); ?>"><?php echo e($r->status == 't' ? 'Aktif' : 'Tidak Aktif'); ?></div>
                            </td>
                            <td align="center">
                                <?php if(isset($access['edit'])): ?>
                                    <a href="#" class="btn btn-icon btn-primary btn-modal" data-form-id="modul" data-id="<?php echo e($r->id); ?>" data-url="/mobiles/activations/" data-action="edit">
                                        <i data-feather="edit"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" align="center">-- Empty Data --</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
            <?php echo e(generatePagination($activations)); ?>

            <form action="" id="formDelete" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" style="display: none">
            </form>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideModalForm::class, ['title' => 'Form Menu']); ?>
<?php $component->withName('side-modal-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e)): ?>
<?php $component = $__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e; ?>
<?php unset($__componentOriginal1533154de035f3218395926c33fdec38f8a8bf8e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/mobiles/activations/index.blade.php ENDPATH**/ ?>