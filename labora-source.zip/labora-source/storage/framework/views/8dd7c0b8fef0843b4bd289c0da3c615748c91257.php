<?php $__env->startSection('content'); ?>
    <?php
        $url = '/attendances/dailies/';
    ?>
    <div class="card">
        <div class="card-header justify-content-between">
            <form class="form-inline" method="GET" id="form">
                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'filter','class' => 'mr-1','value' => ''.e($filter ?? '').'','placeholder' => 'Search ..']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal3c2e9a0b63ed1831aa934d6cc8356b767b33cf80 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectMonth::class, ['name' => 'filterMonth','value' => ''.e($filterMonth).'']); ?>
<?php $component->withName('form.select-month'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c2e9a0b63ed1831aa934d6cc8356b767b33cf80)): ?>
<?php $component = $__componentOriginal3c2e9a0b63ed1831aa934d6cc8356b767b33cf80; ?>
<?php unset($__componentOriginal3c2e9a0b63ed1831aa934d6cc8356b767b33cf80); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal79be037cc48fef95092648bde7c356e360ff7912 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectYear::class, ['name' => 'filterYear','range' => '5','value' => ''.e($filterYear).'']); ?>
<?php $component->withName('form.select-year'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal79be037cc48fef95092648bde7c356e360ff7912)): ?>
<?php $component = $__componentOriginal79be037cc48fef95092648bde7c356e360ff7912; ?>
<?php unset($__componentOriginal79be037cc48fef95092648bde7c356e360ff7912); ?>
<?php endif; ?>
                <input type="submit" class="btn btn-primary" value="GO">
            </form>
            <?php if(isset($access['export'])): ?>
                <a href="<?php echo e(route('attendances.durations.export', ['filter' => $filter, 'filterMonth' => $filterMonth, 'filterYear' => $filterYear])); ?>" class="btn btn-success"><i data-feather='file'></i> Export Data</a>
            <?php endif; ?>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th rowspan="2" class="align-middle text-center" style="min-width: 20px;">No</th>
                    <th rowspan="2" class="align-middle text-center" style="min-width: 200px;">Nama</th>
                    <th rowspan="2" class="align-middle text-center" style="min-width: 100px;">NIK</th>
                    <th colspan="<?php echo e($totalDays); ?>" class="text-center" style="min-width: 1400px;">November 2021</th>
                </tr>
                <tr>
                    <?php for($i = 1; $i<= $totalDays; $i++): ?>
                        <th style="min-width: 100px;" class="text-center"><?php echo e($i); ?></th>
                    <?php endfor; ?>
                </tr>
                </thead>
                <tbody>
                <?php if(!$employees->isEmpty()): ?>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($key+1); ?></td>
                            <td><?php echo e($r->name); ?></td>
                            <td class="text-center"><?php echo e($r->emp_number); ?></td>
                            <?php for($i = 1; $i<= $totalDays; $i++): ?>
                                <?php
                                    $duration = $absenDatas[$r->id][$i] ?? '';
                                ?>
                                <td class="text-center" style="min-width: 30px;"><?php echo e(substr($duration, 0, 5)); ?></td>
                            <?php endfor; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" align="center">-- Empty Data --</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
            <form action="" id="formDelete" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" style="display: none">
            </form>
        </div>
        <?php echo e(generatePagination($employees)); ?>

    </div>
    <style>
        .select2{
            min-width: 130px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/attendances/durations/index.blade.php ENDPATH**/ ?>