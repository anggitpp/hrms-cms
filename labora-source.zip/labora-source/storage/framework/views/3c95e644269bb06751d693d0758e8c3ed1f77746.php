<div class="form-group">
    <div class="row">
        <div class="col-md-3">
            <label for="first-name-vertical"><?php echo e($label); ?></label>
            <input type="text"
                   <?php echo e($attributes->merge(['class' => 'form-control '.$class])); ?>

                   name="<?php echo e($name); ?>"
                   value="<?php echo e(empty($value) ? empty(old($name)) ? '' : old($name) : $value); ?>"
                    <?php echo e($numeric ? 'onkeyup=setNumber(this);' : ''); ?>

            />
        </div>
        <div class="col-md-3">
            <label for="first-name-vertical"><?php echo e($label2); ?></label>
            <input type="text"
                <?php echo e($attributes->merge(['class' => 'form-control '.$class2])); ?>

                name="<?php echo e($name2); ?>"
               value="<?php echo e(empty($value2) ? empty(old($name2)) ? '' : old($name2) : $value2); ?>"
                <?php echo e($numeric ? 'onkeyup=setNumber(this);' : ''); ?>

            />
        </div>
    </div>
</div>
<?php /**PATH /home/buildwit/labora-source/resources/views/components/form/double-input.blade.php ENDPATH**/ ?>