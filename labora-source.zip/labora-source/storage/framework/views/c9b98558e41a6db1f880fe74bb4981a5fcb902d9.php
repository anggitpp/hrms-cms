<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header justify-content-between">
            <h5>
                <?php echo e($emp->name.' - '.$emp->emp_number); ?>

            </h5>
            <h5>
                <?php echo e(setDate($date, 't')); ?>

            </h5>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="5%">No.</th>
                        <th class="text-center" width="45%">Jadwal</th>
                        <th class="text-center" width="50%">Aktual</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(!$monitorings->isEmpty()): ?>
                    <?php $__currentLoopData = $monitorings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($key+1); ?></td>
                            <td class="text-center"><?php echo e($r->start); ?> - <?php echo e($r->end); ?></td>
                            <td class="text-center"><?php echo e($r->actual); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" align="center">-- Empty Data --</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
            <form action="" id="formDelete" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" style="display: none">
            </form>
        </div>
    </div>
    <style>
        .select2{
            min-width: 150px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/monitorings/monitorings/detail.blade.php ENDPATH**/ ?>