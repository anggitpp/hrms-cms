<form id="form-edit" method="POST" class="form-validation"
      action=" <?php echo e(empty($modul) ? route('settings.moduls.store') : route('settings.moduls.update', $modul->id)); ?>"
      enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if(!empty($modul)): ?>
        <?php echo method_field('PATCH'); ?>
    <?php endif; ?>
    <input type="hidden" id="id" value="<?php echo e($modul->id ?? ''); ?>"/>
    <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Name','required' => true,'name' => 'name','placeholder' => 'Name','value' => ''.e($modul->name ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Target','required' => true,'name' => 'target','placeholder' => 'Target','value' => ''.e($modul->target ?? '').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Textarea::class, ['label' => 'Description','name' => 'description','value' => ''.e($modul->description ?? '').'']); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3)): ?>
<?php $component = $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3; ?>
<?php unset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Icon','name' => 'icon','value' => ''.e($modul->icon ?? 'fa fa-folder').'']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Radio::class, ['label' => 'Status','name' => 'status','datas' => $status,'value' => ''.e($modul->status ?? '').'']); ?>
<?php $component->withName('form.radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc)): ?>
<?php $component = $__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc; ?>
<?php unset($__componentOriginalfc3b8b8d15cd7a672ed48daf470a87117a4fb6dc); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['label' => 'Order','name' => 'order','value' => ''.e($modul->order ?? $lastModul).'','class' => 'col-md-2','currency' => true]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
    <button type="button" class="btn btn-primary" style="width: 100%" id="btnSubmit">Save</button>
</form>
<?php /**PATH /home/buildwit/labora-source/resources/views/settings/moduls/form.blade.php ENDPATH**/ ?>