<?php
    $url = "/payrolls/process/";
?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header justify-content-between">
            <form class="form-inline" method="GET" id="form">
                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'filter','class' => 'mr-1','value' => ''.e($filter).'','placeholder' => 'Search ..']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
                <input type="submit" class="btn btn-primary" value="GO">
            </form>
            <?php if(!isset($process) || $process->approve_status != 't'): ?>
                <div class="form-inline">
                    <button class="btn btn-outline-primary waves-effect btnLoading" type="button" disabled="" style="display: none">
                        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                        <span class="ms-25 align-middle">Loading...</span>
                    </button>
                    <buton href="<?php echo e(route('payrolls.process.update', [$typeId, $month, $year])); ?>" class="btn btn-primary ml-2 btnProcess"><i data-feather='repeat'></i> Proses Gaji - <?php echo e(numToMonth($month)." ".$year); ?></buton>
                </div>
            <?php endif; ?>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th width="5%" class="text-center">No</th>
                    <th width="*">Nama</th>
                    <th width="20%" class="text-center">NIK</th>
                    <th width="10%">Nilai</th>
                </tr>
                </thead>
                <tbody>
                <?php if(!$details->isEmpty()): ?>
                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($key + 1); ?></td>
                        <td><?php echo e($r->name); ?></td>
                        <td class="text-center"><?php echo e($r->emp_number); ?></td>
                        <td class="text-right">
                            <a href="#" class="btn-modal-form" data-url="<?php echo e($url); ?>" data-action="detail" data-id="<?php echo e($r->processId."/".$r->id); ?>">
                                <?php echo e(setCurrency($r->value)); ?>

                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" align="center">-- Empty Data --</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
            <?php echo e(generatePagination($details)); ?>

        </div>
    </div>
    <form action="" id="formUpdate" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <input type="submit" style="display: none">
    </form>
    <?php if (isset($component)) { $__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ModalForm::class, ['size' => 'modal-xl','title' => 'Slip Gaji']); ?>
<?php $component->withName('modal-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce)): ?>
<?php $component = $__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce; ?>
<?php unset($__componentOriginal3b6a3d1863995b728ee2efcd7756383c2ac4b9ce); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('.btnProcess').on('click', function (){
            var link = $(this).attr("href");
            Swal.fire({
                title: 'Are you sure?',
                text: "Untuk proses gaji Januari 2022?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('formUpdate').action = link;
                    document.getElementById('formUpdate').submit();
                    $('.btnProcess').hide();
                    $('.btnLoading').show();
                }

            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/payrolls/process/detail.blade.php ENDPATH**/ ?>