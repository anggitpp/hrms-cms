<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Edit Data</h4>
            <div>
                <button type="reset" class="btn btn-primary mr-1" onclick="document.getElementById('form').submit();">
                    Submit
                </button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-secondary mr-1">Cancel</a>
            </div>
        </div>
        <div class="card-body">
            <ul class="nav nav-tabs" role="tablist" style="border-bottom: 1px solid; color: #DFDFDF;">
                <?php $__currentLoopData = $moduls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="home-tab" data-toggle="tab"
                           href="#<?php echo e($modul->target); ?>"
                           aria-controls="<?php echo e($modul->target); ?>" role="tab" aria-selected="true"><?php echo e($modul->name); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <form class="form form-vertical" id="form" method="POST"
                  action="<?php echo e(route('settings.accesses.update', $group->id)); ?>">
                <?php echo method_field('PATCH'); ?>
                <div class="tab-content">
                    <?php $__currentLoopData = $moduls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div role="<?php echo e($loop->first ? 'tabpanel' : 'tab-pane'); ?>"
                             class="tab-pane <?php echo e($loop->first ? 'active' : ''); ?>"
                             id="<?php echo e($modul->target); ?>" aria-labelledby="<?php echo e($modul->target); ?>-tab"
                             aria-expanded="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                            <ul class="nav nav-pills">
                                <?php $__currentLoopData = $modul->submodul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $submoduls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a
                                            class="nav-link<?php echo e($loop->first ? ' active' : ''); ?>"
                                            data-toggle="pill"
                                            href="#<?php echo e($modul->target."-".$submoduls->id); ?>"
                                            aria-expanded="true">
                                            <?php echo e($submoduls->name); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div class="tab-content">
                                <?php $__currentLoopData = $modul->submodul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $submoduls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div
                                        role="tabpanel"
                                        class="tab-pane<?php echo e($loop->first ? ' active' : ''); ?>"
                                        id="<?php echo e($modul->target."-".$submoduls->id); ?>"
                                        aria-labelledby="<?php echo e($modul->target."-".$submoduls->id); ?>"
                                        aria-expanded="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                                        <?php $__currentLoopData = $submoduls->menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kmenu => $vmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="table-responsive border rounded mt-1">
                                                <h6 class="py-1 mx-1 mb-0 font-medium-2">
                                                    <?php echo e($vmenu->name); ?>

                                                    <i data-feather="lock" class="font-medium-3 mr-25"></i>
                                                    <span class="align-middle"></span>
                                                </h6>
                                                <table class="table table-striped table-borderless">
                                                    <thead class="thead-light">
                                                    <tr>
                                                        <th width="*">Permission</th>
                                                        <th width="10%">Method</th>
                                                        <th width="10%">Param</th>
                                                        <th width="5%"></th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php echo csrf_field(); ?>
                                                    <?php $__currentLoopData = $vmenu->menuAccess->where('type', NULL); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kaccess => $vaccess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($vaccess->name); ?></td>
                                                            <td><?php echo e($vaccess->method); ?></td>
                                                            <td><?php echo e($vaccess->param); ?></td>
                                                            <td>
                                                                <div class="custom-control custom-checkbox">
                                                                    <input type="checkbox" class="custom-control-input"
                                                                           value="<?php echo e($key); ?>"
                                                                           name="access[<?php echo e($vmenu->id); ?>_<?php echo e($vaccess->name); ?>]"
                                                                           id="access[<?php echo e($vmenu->id); ?>_<?php echo e($vaccess->name); ?>]"
                                                                        <?php echo e(!empty($menuAccesses[$vmenu->id][$vaccess->name]) ? "checked" : ""); ?>

                                                                    />
                                                                    <label class="custom-control-label"
                                                                           for="access[<?php echo e($vmenu->id); ?>_<?php echo e($vaccess->name); ?>]"></label>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/buildwit/labora-source/resources/views/settings/accesses/form.blade.php ENDPATH**/ ?>