@include('recruitments.selections.index')
